SMAYO ASSET PACKAGE
===================
Folders: 01-hero ... 07-backgrounds each contain
  png-master/  full-resolution lossless PNG (transparent where applicable)
  webp-web/    optimized WebP for production (@1x = half size, for standard-density screens)
08-brand       logo mark (SVG + PNG), favicon.ico, apple-touch-icon, 1200x630 OG image
09-screenshot  full-page homepage screenshot (@2x PNG/JPG, @1x WebP) + source HTML

How the 3D visuals were made: procedural ray-marched (SDF) renders produced with a WebGL shader,
so they are real lit/reflective 3D renders, not AI-generated or stock images. Backgrounds,
network graph and particles are procedurally generated. Palette: #050814, #0c1026, #121836,
#00f2fe, #4facfe, #7f00ff.

Screenshot note: rendered offline with Poppins in place of Inter (Inter isn't installed in the
render environment) and Font Awesome icons inlined as SVG. The live HTML still uses Inter.
